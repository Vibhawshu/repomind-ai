def get_users():
    return db.query(User).all()

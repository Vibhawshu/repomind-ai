def login(user, pw):
    return issue_jwt(user)

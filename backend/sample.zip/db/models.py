class User:
    id: int
